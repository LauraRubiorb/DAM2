package com.example.laura_rubio_damii.ui.model

class User(var email: String, var password: String, var perfil: String) {
}