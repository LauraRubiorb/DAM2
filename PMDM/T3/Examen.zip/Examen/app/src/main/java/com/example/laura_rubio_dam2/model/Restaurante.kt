package com.example.laura_rubio_dam2.model

class Restaurante (var nombre : String,var localidad : String, var puntuacion : Int, var tipoComida : String, var movil : Int, var caracteristicas : Array<String>){


}