package database;

public interface SchemaDB {
    String TABLA1 = "alumno";
    String NOMBRE1 = "nombre";
    String APELLIDO1 = "apellido";
    String DNI1 ="dni";
    String ID1 = "idAlumno";
//----------------------------------
    String TABLA2 = "profesor";
    String NOMBRE2 = "nombre";
    String APELLIDO2 = "apellido";
    String DNI2 = "dni";
    String ASGIN2 = "asignatura";
//-----------------------------------------
String TABLA3 = "proyecto;";
String TITULO3 = "titulo";
String DESC3 = "descripcion";
String CONTENIDO3 = "contenido";
String PROFE3 = "profesorEncargado";
String idAlumno3 = "idAlumno";


}
